# COMP 3007 assignment 1

## INFO
- Owen Craston
- 101037159

### to run
type `./comp3007_f18_101037159_a1_1.py` in the source directory and follow the instructions
